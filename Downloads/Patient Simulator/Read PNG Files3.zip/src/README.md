# SPS Clinical Simulator

Standardized Patient Simulator for clinical communication training at Brown University Health.

## Features

- AI-powered realistic patient interactions
- Comprehensive clinical case generation with OLDCARTS, vitals, medications, and more
- Detailed scoring across 7 clinical rubrics
- OpenAI API integration for natural conversation

## Deployment to Netlify

### Option 1: Deploy via GitHub (Recommended)

1. Push this repository to GitHub
2. Go to [Netlify](https://app.netlify.com)
3. Click "Add new site" → "Import an existing project"
4. Connect your GitHub repository
5. Netlify will auto-detect the build settings from `netlify.toml`
6. Click "Deploy site"

### Option 2: Manual Deploy

1. Run `npm install` to install dependencies
2. Run `npm run build` to create the production build
3. Drag and drop the `dist` folder to Netlify

## Local Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## Configuration

Users will need to provide their own OpenAI API key through the app's settings interface. The API key is stored locally in the browser.

## Tech Stack

- React 18
- TypeScript
- Tailwind CSS v4
- Vite
- Shadcn/ui components
- OpenAI API
