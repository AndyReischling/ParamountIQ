
  # Read PNG Files

  This is a code bundle for Read PNG Files. The original project is available at https://www.figma.com/design/FPzjmTchroLpqqS7AK8xq0/Read-PNG-Files.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  